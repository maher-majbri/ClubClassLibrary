﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClubClassLibrary.Models;

namespace ClubUI
{
    public class App
    {
        public static User CurrentUser = new User();
    }
}
